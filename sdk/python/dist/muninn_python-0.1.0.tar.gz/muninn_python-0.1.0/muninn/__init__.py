"""MuninnDB Python SDK - Async client for cognitive memory database."""

from .client import MuninnClient
from .errors import (
    MuninnAuthError,
    MuninnConflict,
    MuninnConnectionError,
    MuninnError,
    MuninnNotFound,
    MuninnServerError,
    MuninnTimeoutError,
)
from .types import (
    ActivateRequest,
    ActivateResponse,
    ActivationItem,
    BriefSentence,
    CoherenceResult,
    Push,
    ReadResponse,
    StatResponse,
    WriteRequest,
    WriteResponse,
)

__version__ = "0.1.0"

# LangChain integration — only imported if langchain-core is installed.
# Usage: from muninn.langchain import MuninnDBMemory
def __getattr__(name: str):
    if name == "MuninnDBMemory":
        from .langchain import MuninnDBMemory
        return MuninnDBMemory
    raise AttributeError(f"module 'muninn' has no attribute {name!r}")

__all__ = [
    "MuninnClient",
    "MuninnError",
    "MuninnAuthError",
    "MuninnConnectionError",
    "MuninnNotFound",
    "MuninnConflict",
    "MuninnServerError",
    "MuninnTimeoutError",
    "WriteRequest",
    "WriteResponse",
    "ActivateRequest",
    "ActivateResponse",
    "ActivationItem",
    "BriefSentence",
    "ReadResponse",
    "StatResponse",
    "CoherenceResult",
    "Push",
    # Optional (requires langchain-core):
    "MuninnDBMemory",
]
