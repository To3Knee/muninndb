"""MuninnDB type definitions."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


@dataclass
class WriteRequest:
    """Request to write an engram."""

    vault: str
    concept: str
    content: str
    tags: Optional[List[str]] = None
    confidence: float = 0.9
    stability: float = 0.5
    embedding: Optional[List[float]] = None
    associations: Optional[Dict[str, Any]] = None


@dataclass
class WriteResponse:
    """Response from writing an engram."""

    id: str
    created_at: int


@dataclass
class ActivateRequest:
    """Request to activate memory."""

    vault: str
    context: List[str]
    max_results: int = 10
    threshold: float = 0.1
    max_hops: int = 0
    include_why: bool = False
    brief_mode: str = "auto"


@dataclass
class ActivationItem:
    """A single activated memory item."""

    id: str
    concept: str
    content: str
    score: float
    confidence: float
    score_components: Optional[Dict[str, float]] = None
    why: Optional[str] = None
    hop_path: Optional[List[str]] = None
    dormant: bool = False


@dataclass
class BriefSentence:
    """A sentence extracted by brief mode."""

    engram_id: str
    text: str
    score: float


@dataclass
class ActivateResponse:
    """Response from activating memory."""

    query_id: str
    total_found: int
    activations: List[ActivationItem]
    latency_ms: float = 0.0
    brief: Optional[List[BriefSentence]] = None


@dataclass
class ReadResponse:
    """Response from reading an engram."""

    id: str
    concept: str
    content: str
    confidence: float
    relevance: float
    stability: float
    access_count: int
    tags: List[str]
    state: str
    created_at: int
    updated_at: int
    last_access: Optional[int] = None
    coherence: Optional[Dict[str, "CoherenceResult"]] = None
    summary: Optional[str] = None
    key_points: Optional[List[str]] = None
    memory_type: Optional[int] = None
    classification: Optional[int] = None


@dataclass
class CoherenceResult:
    """Coherence metrics for a vault."""

    score: float
    orphan_ratio: float
    contradiction_density: float
    duplication_pressure: float
    decay_variance: float
    total_engrams: int


@dataclass
class StatResponse:
    """Response from stats endpoint."""

    engram_count: int
    vault_count: int
    storage_bytes: int
    coherence: dict[str, CoherenceResult] | None = None


@dataclass
class Push:
    """SSE push event from subscription."""

    subscription_id: str
    trigger: str
    push_number: int
    engram_id: Optional[str] = None
    at: Optional[int] = None
